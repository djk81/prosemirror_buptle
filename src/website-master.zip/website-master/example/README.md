# ProseMirror {{NAME}} example

Interactive view of the [example](http://prosemirror.net/examples/{{NAME}}/) from the [ProseMirror](http://prosemirror.net) website.

You can edit index.js and click "show" at the top of the page to view the results.
